#include "UI.h"

/* 控件链表：后加的在头部，所以最后注册的控件在视觉/命中上都"在上面"。
 * LVGL 用父子树来表达层级，这里为了简单先做扁平链表。 */
static UI_Widget *UI_List   = 0;

/* 当前捕获这次触摸的控件：按下时由命中测试决定，抬起后清空。
 * 对应 LVGL 里的 indev->proc.types.pointer.act_obj */
static UI_Widget *UI_Active = 0;

static uint8_t  UI_LastDown = 0;    /* 上一轮是否处于按下状态 */
static int16_t  UI_LastX    = 0;    /* 最后一次有效坐标（抬手时坐标已经无效，要靠它） */
static int16_t  UI_LastY    = 0;

/**
 * @brief       读硬件：本轮是否有触摸、坐标是多少
 * @param       X, Y : 输出坐标
 * @retval      1=按下, 0=抬起
 * @note        这就是 LVGL 里 indev 的 read_cb，是驱动层和框架层之间唯一的口子。
 *              换成电阻屏/鼠标/按键，只要改这一个函数，上面所有控件都不用动。
 */
static uint8_t UI_ReadInput(int16_t *X, int16_t *Y)
{
    uint8_t n = LCD_T_ScanIT();         /* 中断驱动，没触摸时只是一次判空 */

    if (n)
    {
        *X = (int16_t)TP_Data.X[0];     /* 先只用第一个点；多指要按 ID[] 分发 */
        *Y = (int16_t)TP_Data.Y[0];
        return 1;
    }
    return 0;
}

/**
 * @brief       初始化框架状态
 * @param       无
 * @retval      无
 */
void UI_Init(void)
{
    UI_List     = 0;
    UI_Active   = 0;
    UI_LastDown = 0;
    UI_LastX    = 0;
    UI_LastY    = 0;
}

/**
 * @brief       注册控件（挂到链表头部 = 最上层）
 * @param       Obj : 控件
 * @retval      无
 */
void UI_Add(UI_Widget *Obj)
{
    if (Obj == 0) return;
    Obj->Next = UI_List;
    UI_List   = Obj;
}

/**
 * @brief       注销控件
 * @param       Obj : 控件
 * @retval      无
 */
void UI_Remove(UI_Widget *Obj)
{
    UI_Widget **p = &UI_List;

    while (*p)
    {
        if (*p == Obj) { *p = Obj->Next; Obj->Next = 0; return; }
        p = &(*p)->Next;
    }
}

/**
 * @brief       命中测试：返回坐标处最上层的控件
 * @param       X, Y : 屏幕坐标
 * @retval      控件指针，没有命中返回 0
 * @note        遍历顺序就是层级顺序（链表头部最上层），先命中的就是最上面的
 */
UI_Widget *UI_HitTest(int16_t X, int16_t Y)
{
    UI_Widget *p;

    for (p = UI_List; p; p = p->Next)
    {
        if (X >= p->X && X < (int16_t)(p->X + p->W) &&
            Y >= p->Y && Y < (int16_t)(p->Y + p->H))
            return p;                       /* 命中上层就立刻返回，不再往下找 */
    }
    return 0;
}

/**
 * @brief       取最后一次触摸坐标
 * @param       X, Y : 输出
 * @retval      无
 */
void UI_GetPoint(int16_t *X, int16_t *Y)
{
    if (X) *X = UI_LastX;
    if (Y) *Y = UI_LastY;
}

/**
 * @brief       请求重绘一个控件
 * @param       Obj : 控件
 * @retval      无
 * @note        LVGL 这里是"标脏 + 下帧统一刷"，本框架控件少、区域小，
 *              直接调控件的 Draw 原地重画。以后要做脏矩形，
 *              改成"记录 Obj 的矩形到脏区列表"，再由一个 UI_Flush() 统一刷。
 */
void UI_Invalidate(UI_Widget *Obj)
{
    if (Obj == 0 || Obj->Draw == 0) return;
    Obj->Draw(Obj);
}

/**
 * @brief       安全地发一个事件给指定控件
 * @param       Obj  : 控件，可以为 0（会被忽略）
 * @param       Code : 事件码
 * @retval      无
 */
static void UI_Send(UI_Widget *Obj, UI_EventCode Code)
{
    if (Obj && Obj->Event) Obj->Event(Obj, Code);
}

/**
 * @brief       输入处理：把"按没按 + 坐标"变成事件流并分发
 * @param       无
 * @retval      无
 * @note        主循环每轮调用一次。这个函数就是 LVGL 的 indev 状态机，
 *              区别只是 LVGL 把它藏在库里，这里摊开给你看。
 */
void UI_Process(void)
{
    int16_t x = 0, y = 0;
    uint8_t down = UI_ReadInput(&x, &y);

    if (down && !UI_LastDown)                   /* ① 上升沿：按下 */
    {
        UI_Active = UI_HitTest(x, y);           /* 命中测试选出唯一目标 —— 捕获 */
        if (UI_Active)
        {
            UI_Active->Pressed   = 1;
            UI_Active->LongSent  = 0;
            UI_Active->PressTick = HAL_GetTick();
            UI_LastX = x;
            UI_LastY = y;
            UI_Send(UI_Active, UI_EVENT_PRESSED);
        }
    }
    else if (!down && UI_LastDown)              /* ② 下降沿：抬起 */
    {
        UI_Widget *obj = UI_Active;
        UI_Active = 0;
        if (obj)
        {
            obj->Pressed = 0;
            if (UI_HitTest(UI_LastX, UI_LastY) == obj)   /* 在控件内抬起 = 点击 */
            {
                UI_Send(obj, UI_EVENT_RELEASED);
                UI_Send(obj, UI_EVENT_CLICKED);
            }
            else                                        /* 划出去了 = 这次按作废 */
            {
                UI_Send(obj, UI_EVENT_PRESS_LOST);
            }
        }
    }
    else if (down && UI_Active)                 /* ③ 按住：只有坐标变了才发 PRESSING */
    {
        if (x != UI_LastX || y != UI_LastY)
        {
            UI_LastX = x;
            UI_LastY = y;
            UI_Send(UI_Active, UI_EVENT_PRESSING);
        }
    }

    /* ④ 长按：不依赖触摸事件，靠每轮轮询计时（对应 LVGL 的 lv_timer_handler） */
    if (down && UI_Active && !UI_Active->LongSent &&
        (uint32_t)(HAL_GetTick() - UI_Active->PressTick) >= UI_LONG_PRESS_MS)
    {
        UI_Active->LongSent = 1;
        UI_Send(UI_Active, UI_EVENT_LONG_PRESSED);
    }

    if (down) { UI_LastX = x; UI_LastY = y; }
    UI_LastDown = down;
}

/* ==========================================================================
 *  通用按钮
 * ========================================================================== */

/**
 * @brief       算字符串像素宽度（ASCII 8，汉字 16）
 * @param       Str : UTF-8 字符串
 * @retval      宽度(像素)
 */
int16_t UI_TextWidth(const char *Str)
{
    int16_t w = 0;

    while (Str && *Str)
    {
        uint8_t c = (uint8_t)*Str;

        if (c < 0x80)                       { w += 8;  Str += 1; }
        else if ((c & 0xE0) == 0xC0)        { w += 16; Str += 2; }
        else                                { w += 16; Str += 3; }
    }
    return w;
}

/**
 * @brief       重画按钮
 * @param       Btn : 按钮
 * @retval      无
 * @note        只用黑白：松开 = 黑底白框白字，按下 = 白底黑字。
 *              临时改全局前景/背景色再改回来，等价于 LVGL 的局部样式。
 */
void UI_ButtonDraw(UI_Button *Btn)
{
    UI_Widget *o = &Btn->Base;
    uint16_t   t   = LCD_Param.TextColor;       /* 存下全局配色 */
    uint16_t   b   = LCD_Param.BackColor;
    /* 反色条件：正在按下，或（开关型且已选中）。异或表示"按下时取反" */
    uint8_t    inv = (uint8_t)(o->Pressed ^ (Btn->Toggle && Btn->Checked));

    LCD_Fill((uint16_t)o->X, (uint16_t)o->Y, o->W, o->H, inv ? t : b);
    LCD_DrawRect((uint16_t)o->X, (uint16_t)o->Y, o->W, o->H);       /* 边框用前景色 */

    if (Btn->Text && o->H >= 16)
    {
        int16_t tw = UI_TextWidth(Btn->Text);
        int16_t tx = (int16_t)(o->X + (int16_t)(o->W - tw) / 2);    /* 水平居中 */
        int16_t ty = (int16_t)(o->Y + (int16_t)(o->H - 16) / 2);    /* 垂直居中 */

        if (tx < o->X) tx = o->X;

        if (inv)                                /* 反色：黑底白字 → 白底黑字 */
        {
            LCD_Param.TextColor = b;
            LCD_Param.BackColor = t;
        }

        LCD_ShowString((uint16_t)tx, (uint16_t)ty, Btn->Text, LCD_FONT_8X16);

        LCD_Param.TextColor = t;                /* 复原全局配色 */
        LCD_Param.BackColor = b;
    }
}

/**
 * @brief       基类重画回调（把 UI_Widget* 转回 UI_Button* 再画）
 * @param       Obj : 控件
 * @retval      无
 */
static void UI_ButtonDrawCb(UI_Widget *Obj)
{
    UI_ButtonDraw((UI_Button *)Obj);
}

/**
 * @brief       按钮的事件处理（框架回调，用户不用直接调）
 * @param       Obj  : 控件（实际类型是 UI_Button）
 * @param       Code : 事件码
 * @retval      无
 * @note        注意这里没有一个地方判断"上一帧按没按" —— 状态机在 UI_Process 里，
 *              控件只对"已经发生的事件"做反应，这就是分层带来的简化。
 */
static void UI_ButtonEvent(UI_Widget *Obj, UI_EventCode Code)
{
    /* 基类指针转派生类：基类必须是第一个成员，地址才是同一个 */
    UI_Button *btn = (UI_Button *)Obj;

    switch (Code)
    {
    case UI_EVENT_PRESSED:
        UI_Invalidate(Obj);                         /* 变反色 */
        break;

    case UI_EVENT_PRESSING:
    {
        int16_t px, py;
        uint8_t inside;

        UI_GetPoint(&px, &py);
        inside = (uint8_t)(UI_HitTest(px, py) == Obj);   /* 手指还在自己身上吗 */

        if (inside != Obj->Pressed)                 /* 只在跨过边界时重画一次 */
        {
            Obj->Pressed = inside;
            UI_Invalidate(Obj);
        }
        break;
    }

    case UI_EVENT_RELEASED:
    case UI_EVENT_PRESS_LOST:
        UI_Invalidate(Obj);                         /* 恢复常态 */
        break;

    case UI_EVENT_CLICKED:
        if (btn->Toggle) btn->Checked = (uint8_t)!btn->Checked;
        UI_Invalidate(Obj);                         /* 开关型要立刻反映新状态 */
        if (btn->OnClick) btn->OnClick(Obj);
        break;

    default:
        break;
    }
}

/**
 * @brief       创建按钮
 * @param       Btn     : 按钮对象（由调用者分配，static 或全局）
 * @param       X, Y, W, H : 位置尺寸
 * @param       Text    : 文字，可为 0
 * @param       OnClick : 点击回调，可为 0
 * @retval      无
 */
void UI_ButtonInit(UI_Button *Btn, int16_t X, int16_t Y, uint16_t W, uint16_t H,
                   const char *Text, void (*OnClick)(struct UI_Widget *Obj))
{
    if (Btn == 0) return;

    Btn->Base.X       = X;
    Btn->Base.Y       = Y;
    Btn->Base.W       = W;
    Btn->Base.H       = H;
    Btn->Base.Pressed = 0;
    Btn->Base.LongSent = 0;
    Btn->Base.PressTick = 0;
    Btn->Base.Event   = UI_ButtonEvent;
    Btn->Base.Draw    = UI_ButtonDrawCb;
    Btn->Base.Next    = 0;

    Btn->Text    = Text;
    Btn->Toggle  = 0;
    Btn->Checked = 0;
    Btn->OnClick = OnClick;

    UI_Add(&Btn->Base);
    UI_ButtonDraw(Btn);
}
