#ifndef INC_3_5TFTLCD_UI_H
#define INC_3_5TFTLCD_UI_H

#include "main.h"
#include "LCD.h"

/* ==========================================================================
 *  一个极简的 GUI 事件框架，结构刻意模仿 LVGL，方便对照学习：
 *
 *    LVGL 概念                    这里的对应物
 *    ------------------------------------------------------------------
 *    lv_indev_drv_t.read_cb       UI_ReadInput()      读硬件，出"按下+坐标"
 *    lv_indev 的状态机             UI_Process()        生成 PRESSED/PRESSING/...
 *    lv_obj_t                     UI_Widget           所有控件的基类
 *    lv_btn / lv_slider ...       UI_Button           派生控件（基类放第一个成员）
 *    lv_obj_add_event_cb()        Obj->Event          事件回调
 *    lv_obj_invalidate()          UI_Invalidate()     标记重绘（这里直接重画）
 *    lv_indev->proc...act_obj     UI_Active           当前"捕获"这次触摸的控件
 *
 *  为什么要有"捕获"：按下时用命中测试选出唯一的目标控件，之后的
 *  移动和抬起全部只发给它。控件因此永远不需要自己保存"上一帧按没按"。
 * ========================================================================== */

/* 事件码，命名和 LVGL 的 lv_event_code_t 一一对应（括号里是 LVGL 名字） */
typedef enum
{
    UI_EVENT_PRESSED = 0,       /* (LV_EVENT_PRESSED)      手指刚按下            */
    UI_EVENT_PRESSING,          /* (LV_EVENT_PRESSING)     按住并移动            */
    UI_EVENT_RELEASED,          /* (LV_EVENT_RELEASED)     在控件内抬起          */
    UI_EVENT_CLICKED,           /* (LV_EVENT_CLICKED)      抬起且算一次点击      */
    UI_EVENT_PRESS_LOST,        /* (LV_EVENT_PRESS_LOST)   划出控件后抬起        */
    UI_EVENT_LONG_PRESSED       /* (LV_EVENT_LONG_PRESSED) 按住超过 UI_LONG_PRESS_MS */
} UI_EventCode;

#define UI_LONG_PRESS_MS    800     /* 长按判定时间(ms) */

struct UI_Widget;
typedef void (*UI_EventCb)(struct UI_Widget *Obj, UI_EventCode Code);
typedef void (*UI_DrawCb)(struct UI_Widget *Obj);

/* 控件基类，相当于 lv_obj_t */
typedef struct UI_Widget
{
    int16_t   X, Y;             /* 左上角坐标 */
    uint16_t  W, H;             /* 尺寸 */
    uint8_t   Pressed;          /* 1 = 当前被按住 */
    uint8_t   LongSent;         /* 长按已上报过，防止重复触发 */
    uint32_t  PressTick;        /* 按下时刻(ms) */
    UI_EventCb Event;           /* 事件回调（对应 lv_obj 的 event_cb） */
    UI_DrawCb  Draw;            /* 重画回调（对应 lv_obj_class 的 draw 方法） */
    struct UI_Widget *Next;     /* 控件链表（LVGL 是父子树，这里先做扁平链表） */
} UI_Widget;

/* ---------------- 框架 API ---------------- */
void        UI_Init(void);                                  /* 清空控件表和状态 */
void        UI_Add(UI_Widget *Obj);                         /* 注册控件，后加的在上层 */
void        UI_Remove(UI_Widget *Obj);                      /* 注销控件 */
UI_Widget  *UI_HitTest(int16_t X, int16_t Y);               /* 坐标处最上层的控件，没有则返回 0 */
void        UI_GetPoint(int16_t *X, int16_t *Y);            /* 取最后一次触摸坐标（对应 lv_indev_get_point） */
void        UI_Invalidate(UI_Widget *Obj);                  /* 请求重绘（派生控件自己实现重画） */
void        UI_Process(void);                               /* 主循环每轮调一次：读触摸 → 生成事件 → 分发 */

/* ---------------- 通用按钮控件 ---------------- */
typedef struct
{
    UI_Widget   Base;           /* 【必须放第一个】相当于 lv_btn 内含 lv_obj_t */
    const char *Text;
    uint8_t     Toggle;         /* 1 = 开关型，点击时切换 Checked */
    uint8_t     Checked;        /* 开关状态 */
    void      (*OnClick)(struct UI_Widget *Obj);
} UI_Button;

void    UI_ButtonInit(UI_Button *Btn, int16_t X, int16_t Y, uint16_t W, uint16_t H,
                      const char *Text, void (*OnClick)(struct UI_Widget *Obj));
void    UI_ButtonDraw(UI_Button *Btn);
int16_t UI_TextWidth(const char *Str);                      /* 算字符串像素宽度 */

#endif // INC_3_5TFTLCD_UI_H
