#ifndef __LED_H
#define __LED_H

#include "main.h"
#include <stdbool.h>

void LED_ON(bool LED);
void LED_OFF(bool LED);
void LED_Turn(bool LED);

#endif
